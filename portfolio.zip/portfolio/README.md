# Osobní portfolio — dokumentace

Kompletní responzivní portfolio v tmavém glassmorphism stylu (Apple / Tesla / Framer
inspirace) s vlastní skrytou administrací. Bez frameworků, bez buildu — stačí otevřít
`index.html` v prohlížeči.

## Struktura projektu

```
index.html        veřejný web
admin.html         administrace (skrytá)
css/style.css       styly veřejného webu
css/admin.css       styly administrace
js/data.js           datová vrstva (LocalStorage) — sdílená oběma stránkami
js/main.js            logika veřejného webu, animace, vykreslení dat
js/admin.js            logika administrace (CRUD, kalendář, poznámky, nastavení)
```

## Spuštění

Stačí otevřít `index.html` dvojklikem, nebo přes lokální server (doporučeno kvůli
některým prohlížečům, které omezují `file://`), např.:

```
npx serve .
```

## Jak funguje administrace

Administrace je záměrně neviditelná — na webu není žádné tlačítko „Admin“.

**Přístup č. 1:** 5× rychle klikněte na logo („JAN.NOVÁK“) v navigaci nebo na jméno
v Hero sekci. Vyskočí okno pro zadání hesla. Po správném zadání jste přesměrováni na
`/admin.html`.

**Přístup č. 2:** Kdekoliv na domovské stránce napište (na klávesnici) heslo
`adminmama43` — administrace se otevře automaticky.

**Výchozí heslo:** `adminmama43` (lze změnit v Nastavení administrace).

`admin.html` lze otevřít i přímo — vždy ale vyžaduje zadání hesla, dokud v rámci
aktuální relace prohlížeče nejste ověřeni.

## Ukládání dat

Veškerý obsah (fotografie, texty, odkazy, poznámky, kalendář…) se ukládá do
`localStorage` prohlížeče pod klíči s prefixem `pf_`. Nic se nezapisuje přímo do HTML.
Všechny změny v administraci se ihned promítnou na veřejném webu.

**Důležité:** `localStorage` je vázaný na konkrétní prohlížeč a zařízení. Pro sdílení
dat mezi zařízeními použijte v Nastavení tlačítko **Exportovat data** (stáhne se JSON
záloha) a na druhém zařízení ji přes **Importovat data** nahrajte zpět.

Fotografie se ukládají jako Base64 přímo v datech — u velkého množství vysokého
rozlišení fotografií proto může dojít k naplnění limitu `localStorage`
(obvykle 5–10 MB dle prohlížeče). Pro produkční nasazení s velkým množstvím fotek
doporučujeme v budoucnu napojit skutečné úložiště / backend.

## Co administrace umí

- Domovská stránka (jméno, slogan, fotka)
- O mně (text, fotka)
- Životopis (praxe, vzdělání, certifikáty, dovednosti, jazyky, ŘP, soft/hard skills)
  — vše editovatelné bez zásahu do HTML
- Fotogalerie — nahrávání z telefonu/galerie/souborů, mazání, přeuspořádání
  přetažením
- Externí spolupráce — název, URL, logo (nebo automatický favicon), popis
- Sociální sítě a kontakty
- Dovednosti s animovanými progress bary
- Portfolio projektů
- Reference klientů
- Poznámky (barva, priorita, štítky, hotovo/nehotovo, propojení s kalendářem)
- Kalendář s událostmi a připomínkami
- Zprávy z kontaktního formuláře
- Nastavení: změna hesla, export/import dat, vymazání cache

## Technologie

HTML5, CSS3, vanilla JavaScript (ES6). Pro animace GSAP + ScrollTrigger a plynulý
scroll knihovna Lenis (načítány z CDN). Ikony z knihovny Lucide.

## Přizpůsobení designu

Barvy, typografie a rozestupy jsou definované jako CSS proměnné v horní části
`css/style.css` (sekce `:root`) — stačí upravit hodnoty a projeví se v celém webu.
